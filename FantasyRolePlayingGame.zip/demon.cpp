#include "demon.h"
#include <iostream>

Demon::Demon(){
	setType(-1);
	setStrength(1);/*Strength = 1 because if strengt = 0 ,
				  when created in main Creature object with no parameter,
				  we take "Floating point exception error --> rand() % strenght "*/
	setHitpoints(0);
}

Demon::Demon(int newType,int newStrength,int newHit):Creature(newType,newStrength,newHit){
	/*If object is Balrog newType = 2 else if object is Cyberdemon newType = 1*/
}

std::string Demon::getSpecies(){return "Demon";}

int Demon::getDamage(){
	int damage = Creature::getDamage();
	if(rand() % 100 < 5){ /* Demons can inflict damage of 50 with a 5% chance */
		damage = damage + 50;
	}
	return damage;
}