#ifndef DEMON_H
#define DEMON_H
#include "creature.h"

class Demon:public Creature{
private:
	std::string getSpecies();
public:
	Demon();
	Demon(int newType,int newStrength,int newHit);
	int getDamage();
};

#endif
