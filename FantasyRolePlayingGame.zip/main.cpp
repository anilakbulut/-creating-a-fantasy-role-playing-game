#include <iostream>
#include "creature.h"
#include "elf.h"
#include "demon.h"
#include "human.h"
#include "balrog.h"
#include "cyberdemon.h"

using namespace std;

int main(int argc, char const *argv[])
{
	Elf obj1(34,42);
	obj1.getDamage();

	Balrog obj2(100,15);
	obj2.getDamage();

	Cyberdemon obj3(250,15);
	obj3.getDamage();

	Human obj4(50,40);
	obj4.getDamage();

	cout<<endl;

	Elf obj5;
	obj5.getDamage();

	Balrog obj6;
	obj6.getDamage();

	Cyberdemon obj7;
	obj7.getDamage();

	Human obj8;
	obj8.getDamage();

	return 0;
}