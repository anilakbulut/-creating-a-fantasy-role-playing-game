#ifndef CYBERDEMON_H
#define CYBERDEMON_H
#include "demon.h"

class Cyberdemon:public Demon{
private:
	std::string getSpecies();
public:
	Cyberdemon();
	Cyberdemon(int newStrength,int newHit);
	int getDamage();
};

#endif