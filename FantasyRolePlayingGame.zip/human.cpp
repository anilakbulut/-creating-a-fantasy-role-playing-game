#include "human.h"
#include <iostream>

Human::Human(){
	setType(0);
	setStrength(10);
	setHitpoints(10);
}

Human::Human(int newStrength,int newHit):Creature(0,newStrength,newHit){
	/*int newType = 0 */
}
std::string Human::getSpecies(){return "Human";}

int Human::getDamage(){
	int damage = Creature::getDamage();
	std::cout << getSpecies() << " attacks for " << damage << " points!" << std::endl;
	return damage;
}