#include "creature.h"
#include<cstdlib>
#include<ctime>
#include <iostream>

using namespace std;

Creature::Creature(){
	type = 0; 
	strength = 1; /*Strength = 1 because if strengt = 0 ,
				  when created in main Creature object with no parameter,
				  we take "Floating point exception error --> rand() % strenght "*/
	hitpoints = 0;
}

Creature::Creature(int newType,int newStrength,int newHit){
	type = newType;
	strength = newStrength;
	hitpoints = newHit;
}
std::string Creature::getSpecies(){return "Unknown";}

int Creature::getStrength(){return strength;}
int Creature::getHitpoints(){return hitpoints;}
int Creature::getType(){return type;}

void Creature::setType(int newType){type=newType;}
void Creature::setStrength(int newStrength){strength=newStrength;}
void Creature::setHitpoints(int newHit){hitpoints=newHit;}

int Creature::getDamage(){
	int damage;
	srand(time(NULL));
	damage = (rand() % strength) + 1;
	return damage;
}