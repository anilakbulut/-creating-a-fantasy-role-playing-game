#ifndef ELF_H
#define ELF_H
#include "creature.h"

class Elf:public Creature{
private:
	std::string getSpecies();
public:
	Elf();
	Elf(int newStrength,int newHit);
	int getDamage();
};

#endif