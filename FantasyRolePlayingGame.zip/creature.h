#ifndef CREATURE_H
#define CREATURE_H
#include <string>

class Creature{
private:
	int type;/*Type of creatures*/
	int strength;
	int hitpoints;
	std::string getSpecies();/*return Creatures names*/
public:
	Creature();/*no parameter constructor*/
	Creature(int newType,int newStrength,int newHit);/*other constructor*/
	/*getter*/
	int getType();
	int getStrength();
	int getHitpoints();
	int getDamage();
	/*setter*/
	void setType(int newType);
	void setStrength(int newStrength);
	void setHitpoints(int newHit);

};

#endif
