#ifndef BALROG_H
#define BALROG_H
#include "demon.h"

class Balrog:public Demon{
private:
	std::string getSpecies();
public:
	Balrog();
	Balrog(int newStrength,int newHit);
	int getDamage();
};

#endif
