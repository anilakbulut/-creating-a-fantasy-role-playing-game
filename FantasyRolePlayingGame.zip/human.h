#ifndef HUMAN_H
#define HUMAN_H
#include "creature.h"

class Human:public Creature{
private:
	std::string getSpecies();
public:
	Human();
	Human(int newStrength,int newHit);
	int getDamage();
};

#endif