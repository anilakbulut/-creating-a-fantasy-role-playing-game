#include "cyberdemon.h"
#include <iostream>

Cyberdemon::Cyberdemon(){
	setType(1);/*1 is cyberdemon*/
	setStrength(1);/*Strength = 1 because if strengt = 0 ,
				  when created in main Creature object with no parameter,
				  we take "Floating point exception error --> rand() % strenght "*/
	setHitpoints(0);
}

Cyberdemon::Cyberdemon(int newStrength,int newHit):Demon(1,newStrength,newHit){
	/*int newType = 1 */
}
std::string Cyberdemon::getSpecies(){return "Cyberdemon";}

int Cyberdemon::getDamage(){
	int damage = Demon::getDamage();/*Cyberdemon's damage equal to Demon object's damage*/
	std::cout << getSpecies() << " attacks for " << damage << " points!" << std::endl;
	return damage;
}
