#include "elf.h"
#include <iostream>

Elf::Elf(){
	setType(3);/*3 is Elves*/
	setStrength(1);/*Strength = 1 because if strengt = 0 ,
				  when created in main Creature object with no parameter,
				  we take "Floating point exception error --> rand() % strenght "*/
	setHitpoints(0);
}

Elf::Elf(int newStrength,int newHit):Creature(3,newStrength,newHit){
	/*int newType = 3 */
}
std::string Elf::getSpecies(){return "Elf";}

int Elf::getDamage(){
	int damage = Creature::getDamage();
	if(rand() % 100 < 10) {  /*Elves inflict double magical damage with a 10% chance */
		damage = damage * 2;
	}
	std::cout << getSpecies() << " attacks for " << damage << " points!" << std::endl; 
	
	return damage;
}