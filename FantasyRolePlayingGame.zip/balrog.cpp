#include "balrog.h"
#include <iostream>

Balrog::Balrog(){
	setType(2);/*2 is balrog*/
	setStrength(1);/*Strength = 1 because if strengt = 0 ,
				  when created in main Creature object with no parameter,
				  we take "Floating point exception error --> rand() % strenght "*/
	setHitpoints(0);
}

Balrog::Balrog(int newStrength,int newHit):Demon(2,newStrength,newHit){
	/*int newType = 2*/
}

std::string Balrog::getSpecies(){return "Balrog";}

int Balrog::getDamage(){
	int damage = Demon::getDamage();
	damage = damage * 2; /*Balrogs are so fast they get to attack twice*/
	std::cout << getSpecies() << " attacks for " << damage << " points!" << std::endl;
	return damage;
}